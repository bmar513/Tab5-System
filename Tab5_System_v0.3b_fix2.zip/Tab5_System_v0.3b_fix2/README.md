# Tab5 System v0.3b — Fix 2

MP3 playback optimization: removes the 10 ms loop delay during decoding and adds a 32 KiB filesystem read-ahead buffer using ESP8266Audio's AudioFileSourceBuffer.

This is an experimental source-only fix, not compiled or tested on physical Tab5 hardware. WAV playback and Generator preview are retained.

**Recorder remains unimplemented.** The Record button still reports MIC RECORDING NOT CONNECTED. Actual microphone recording requires integrating and validating M5.Mic capture and WAV writing on the ESP32-P4; no claim of microphone recording is made.

The previous PDM compatibility exclusion build script is retained. Open the folder containing platformio.ini in VS Code.
