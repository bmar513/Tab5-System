# PlatformIO build middleware: exclude the unused PDM output driver.
# ESP8266Audio 2.4.3 PDM source expects newer ESP-IDF definitions
# than those provided by pioarduino 54.03.21 / Arduino 3.2.1.
Import("env")

def exclude_unused_pdm(node):
    return None

env.AddBuildMiddleware(exclude_unused_pdm, "*AudioOutputPDM.cpp")
