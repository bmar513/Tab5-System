# Tab5 System v0.3c

Based on confirmed-working v0.3b_fix2.

- Global volume and previous unmuted volume persist via ESP32 Preferences (NVS).
- Player transport buttons are drawn with M5GFX triangles and rectangles, not image files.
- MP3 streaming with 32 KiB read-ahead buffer retained.
- MP3 rewind and fast-forward by approximately 15 seconds; uses an estimated bitrate from the first MPEG-1 Layer III frame. Accuracy varies with VBR, ID3 and other formats. WAV seeking remains unsupported.

NOTE: This source has not been compiled or hardware tested. Seek implementation is experimental and may fail for some MP3 files; keep the previous firmware available. Recorder and Sequencer audio are not changed.
