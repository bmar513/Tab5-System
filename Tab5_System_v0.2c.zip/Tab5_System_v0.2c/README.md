# Tab5 System v0.2c

Based on v0.2b. Reader now streams TXT/MD/LOG files from SD rather than
loading them into a 64 KiB String. Page boundaries are calculated using the
actual rendered line wrapping; PREV recomputes the previous boundary from the
start of the file. For large books this may take time, but RAM use stays bounded.
Reader file-open errors appear in the file list. Notes retains its independent
64 KiB editable-text limit. SD browser remains browse-only.

This source has not been compiled or hardware tested.
