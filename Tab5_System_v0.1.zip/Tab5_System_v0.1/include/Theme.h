#pragma once
#include <stdint.h>
namespace Theme {
constexpr uint32_t BG = 0x000000;
constexpr uint32_t PANEL = 0x0C0C0C;
constexpr uint32_t EDGE = 0x79400D;
constexpr uint32_t ORANGE = 0xFF981A;
constexpr uint32_t YELLOW = 0xFFCB38;
constexpr uint32_t RED = 0xE63D23;
constexpr uint32_t WHITE = 0xF5F2E9;
constexpr uint32_t MUTED = 0xA6A09A;
}
