#include <Arduino.h>
#include <M5Unified.h>
#include <M5GFX.h>
#include <esp_heap_caps.h>
#include "Theme.h"
using namespace Theme;
namespace {
constexpr int HEADER_H = 94;
constexpr int FOOTER_H = 44;
constexpr int APP_COUNT = 12;
const char* const labels[APP_COUNT] = {"PLAYER","RECORDER","SEQUENCER","GENERATOR","SYNTH PIANO","NOTES","EREADER","SD","DIAGNOSTICS","LOREM","IPSUM","DOLOR"};
const char* const descriptions[APP_COUNT] = {
 "Music and saved clips","Record and trim WAV samples","16-step sample patterns","Create waveform samples",
 "Keyboard and clip recording","Text editor","Books and reading position","SD file management",
 "Hardware and memory","Reserved","Reserved","Reserved"
};
int activeApp = -1;
int screenW = 1280, screenH = 720;
bool touchWasDown = false;
uint32_t lastBattery = 0;
int lastBatteryLevel = -999;

void text(const String& s, int x, int y, int scale, uint32_t color, uint32_t background=BG) {
 M5.Display.setTextColor(color,background);
 M5.Display.setTextSize(scale);
 M5.Display.setCursor(x,y);
 M5.Display.print(s);
}
void panel(int x,int y,int w,int h,bool selected=false) {
 M5.Display.fillRoundRect(x,y,w,h,12,PANEL);
 M5.Display.drawRoundRect(x,y,w,h,12,selected?ORANGE:EDGE);
}
void icon(int id,int x,int y) {
 // Small line-art icons drawn with display primitives, no bitmap files.
 auto &d=M5.Display;
 const uint32_t c=ORANGE;
 switch(id) {
 case 0: // music note
  d.drawLine(x+22,y+5,x+22,y+28,c); d.drawLine(x+22,y+5,x+36,y+1,c);d.drawLine(x+36,y+1,x+36,y+23,c);
  d.fillCircle(x+16,y+29,6,c);d.fillCircle(x+30,y+24,6,c);break;
 case 1: // microphone
  d.fillRoundRect(x+17,y+3,14,26,7,c);d.drawArc(x+24,y+23,17,17,0,180,c);d.drawLine(x+24,y+39,x+24,y+45,c);d.drawLine(x+14,y+45,x+34,y+45,c);break;
 case 2: // step sequencer
  for(int i=0;i<4;i++)for(int j=0;j<4;j++){int px=x+2+i*12,py=y+2+j*12;d.fillRoundRect(px,py,9,9,2,(i+j)%3==0?YELLOW:EDGE);}break;
 case 3: // waveform
  for(int i=0;i<9;i++){int h=(i%4==0?8:i%3==0?32:i%2==0?23:15);d.drawFastVLine(x+4+i*5,y+24-h/2,h,c);}break;
 case 4: // piano keys
  d.drawRect(x+2,y+6,46,36,c);for(int i=1;i<7;i++)d.drawFastVLine(x+2+i*7,y+7,34,c);
  for(int i: {1,2,4,5})d.fillRect(x+2+i*7-3,y+7,5,18,c);break;
 case 5: // notes
  d.drawRoundRect(x+8,y+3,32,43,3,c);for(int i=0;i<4;i++)d.drawFastHLine(x+15,y+13+i*8,18,c);break;
 case 6: // open book
  d.drawLine(x+24,y+10,x+24,y+42,c);d.drawLine(x+4,y+8,x+4,y+39,c);d.drawLine(x+44,y+8,x+44,y+39,c);
  d.drawLine(x+4,y+8,x+24,y+12,c);d.drawLine(x+44,y+8,x+24,y+12,c);d.drawLine(x+4,y+39,x+24,y+43,c);d.drawLine(x+44,y+39,x+24,y+43,c);break;
 case 7: // SD card
  d.drawRect(x+9,y+5,31,39,c);d.fillRect(x+15,y+8,19,13,c);d.drawLine(x+9,y+5,x+17,y+5,c);d.drawFastHLine(x+16,y+35,17,c);break;
 case 8: // diagnostics
  d.drawCircle(x+24,y+24,19,c);d.drawLine(x+8,y+25,x+16,y+25,c);d.drawLine(x+16,y+25,x+20,y+14,c);d.drawLine(x+20,y+14,x+27,y+35,c);d.drawLine(x+27,y+35,x+33,y+25,c);d.drawLine(x+33,y+25,x+41,y+25,c);break;
 default: // reserved buttons
  d.drawRoundRect(x+8,y+8,32,32,6,EDGE);d.drawFastHLine(x+18,y+24,12,c);d.drawFastVLine(x+24,y+18,12,c);break;
 }
}
void drawBattery(bool force=false) {
 int level=M5.Power.getBatteryLevel();
 if(level<0||level>100) level=-1;
 if(!force && level==lastBatteryLevel)return;
 lastBatteryLevel=level;
 int x=screenW-164,y=30;
 M5.Display.fillRect(x-8,y-5,160,43,BG);
 M5.Display.drawRoundRect(x,y,43,24,4,ORANGE);
 M5.Display.fillRect(x+44,y+7,4,10,ORANGE);
 if(level>=0) {
  int fill=(level*35)/100;
  if(fill>0)M5.Display.fillRect(x+4,y+4,fill,16,level<=15?RED:YELLOW);
  text(String(level)+"%",x+58,y+4,2,WHITE);
 } else text("--%",x+58,y+4,2,MUTED);
}
void chrome(const String& page) {
 M5.Display.fillScreen(BG);
 M5.Display.fillRect(0,0,screenW,4,ORANGE);
 text("TAB5 SYSTEM",26,24,3,ORANGE);
 text("TAB5  /  v0.1",28,63,1,MUTED);
 drawBattery(true);
 M5.Display.drawFastHLine(22,HEADER_H,screenW-44,EDGE);
}
void drawHome() {
 chrome("HOME");
 const int gap=14,left=26,top=HEADER_H+18;
 const int cardW=(screenW-left*2-gap*3)/4;
 const int cardH=(screenH-top-24-gap*2)/3;
 for(int i=0;i<APP_COUNT;i++){
  int x=left+(i%4)*(cardW+gap),y=top+(i/4)*(cardH+gap);
  panel(x,y,cardW,cardH);
  icon(i,x+19,y+14);
  text(labels[i],x+20,y+71,2,i>=9?YELLOW:WHITE);
  text(descriptions[i],x+20,y+107,1,MUTED);
 }
}
void homeButton(){panel(screenW-206,screenH-91,178,43,true);text("< HOME",screenW-184,screenH-79,2,ORANGE);}
void drawDiagnostics() {
 chrome("DIAGNOSTICS");
 panel(26,112,screenW-52,screenH-112-FOOTER_H-16);
 const size_t freeInternal=heap_caps_get_free_size(MALLOC_CAP_INTERNAL);
 const size_t freePsram=heap_caps_get_free_size(MALLOC_CAP_SPIRAM);
 const size_t totalPsram=heap_caps_get_total_size(MALLOC_CAP_SPIRAM);
 const String rows[]={
  "CPU: "+String(ESP.getChipModel())+"  |  "+String(ESP.getCpuFreqMHz())+" MHz",
  "Chip revision: "+String(ESP.getChipRevision()),
  "Flash: "+String(ESP.getFlashChipSize()/1024/1024)+" MB",
  "Internal free heap: "+String(freeInternal/1024)+" KB",
  "PSRAM: "+String(totalPsram/1024/1024)+" MB total / "+String(freePsram/1024/1024)+" MB free",
  "Display: "+String(screenW)+" x "+String(screenH),
  "Uptime at opening: "+String(millis()/1000)+" sec",
  "SD, keyboard, audio: pending hardware validation"
 };
 for(int i=0;i<8;i++)text(rows[i],55,140+i*53,2,i==7?MUTED:WHITE);
 homeButton();
}
void drawApp(){
 if(activeApp<0){drawHome();return;}
 if(activeApp==8){drawDiagnostics();return;}
 chrome(labels[activeApp]);
 panel(26,115,screenW-52,screenH-115-FOOTER_H-16);
 text(labels[activeApp],58,165,3,ORANGE);
 text(descriptions[activeApp],58,226,2,MUTED);
 text("UI placeholder - application engine comes in later milestones",58,300,2,YELLOW);
 homeButton();
}
void handleTouch(int x,int y){
 if(activeApp>=0){
  if(y<HEADER_H || (x>screenW-235 && y>screenH-113)){activeApp=-1;drawHome();}
  return;
 }
 const int gap=14,left=26,top=HEADER_H+18;
 const int cardW=(screenW-left*2-gap*3)/4;
 const int cardH=(screenH-top-24-gap*2)/3;
 for(int i=0;i<APP_COUNT;i++){
  int px=left+(i%4)*(cardW+gap),py=top+(i/4)*(cardH+gap);
  if(x>=px&&x<px+cardW&&y>=py&&y<py+cardH){
   if(i>=9)return; // Reserved slots are intentionally inert.
   activeApp=i;drawApp();return;
  }
 }
}
}
void setup(){
 Serial.begin(115200);
 auto cfg=M5.config();
 M5.begin(cfg);
 M5.Display.setRotation(3); // 180 degrees relative to v0.0 rotation 1
 screenW=M5.Display.width();screenH=M5.Display.height();
 drawHome();lastBattery=millis();
 Serial.println("Tab5 System v0.1 ready");
}
void loop(){
 M5.update();
 auto t=M5.Touch.getDetail();
 bool down=t.isPressed();
 if(down&&!touchWasDown)handleTouch(t.x,t.y);
 touchWasDown=down;
 if((uint32_t)(millis()-lastBattery)>=60000){lastBattery=millis();drawBattery();}
 delay(10);
}
