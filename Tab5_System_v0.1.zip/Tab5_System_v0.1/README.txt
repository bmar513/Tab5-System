Tab5 System v0.1 - source-only PlatformIO project

Changes: 180 degree display rotation; black/orange/yellow/red shared theme;
no home footer; battery indicator updated once per minute (only when value changes);
12 home buttons with last three LOREM IPSUM DOLOR inert;
vector icons instead of numbered circles; diagnostics no periodic redraw.

Build and upload in PowerShell from this folder:
& "$env:USERPROFILE\.platformio\penv\Scripts\platformio.exe" run -e tab5 -t upload --upload-port COM7

The .pio build cache is intentionally excluded. PlatformIO recreates it.
Battery percentage depends on M5Unified device support; --% indicates unavailable.
Touch orientation needs physical verification after the rotation change.
