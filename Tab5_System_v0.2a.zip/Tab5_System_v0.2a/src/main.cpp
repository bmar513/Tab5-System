
#include <Arduino.h>
#include <M5Unified.h>
#include <M5GFX.h>
#include <SD_MMC.h>
#include <esp_heap_caps.h>
#include <esp_mac.h>
#include "Theme.h"

namespace {
constexpr uint32_t BG=Theme::BG, PANEL=Theme::PANEL, EDGE=Theme::EDGE;
constexpr uint32_t C_ORANGE=Theme::ORANGE,C_YELLOW=Theme::YELLOW,C_RED=Theme::RED;
constexpr uint32_t C_WHITE=Theme::WHITE,C_MUTED=Theme::MUTED;
constexpr int HEADER=65, COUNT=12, MAX_FILES=120;
const char* labels[COUNT]={"PLAYER","RECORDER","SEQUENCER","GENERATOR","SYNTH PIANO","NOTES","EREADER","SD","DIAGNOSTICS","LOREM","IPSUM","DOLOR"};
int W=1280,H=720,app=-1,scrollOffset=0,readerOffset=0;
bool sdOK=false, touchDown=false,editing=false,dirty=false;
uint32_t batteryTick=0;
int oldBattery=-999;
String folder="/", filePath="", editor="", notice="";
struct Entry {String name,path;bool directory;};
Entry entries[MAX_FILES];int count=0;
const char* const dirs[]={"/Music","/Recordings","/Samples","/Samples/Drums","/Samples/Synth","/Samples/Generated","/Patterns","/Notes","/Books","/Books/TXT","/Books/EPUB","/Books/PDF","/System","/System/Settings"};
void print(const String&s,int x,int y,int sz=2,uint32_t color=C_WHITE){
 M5.Display.setTextColor(color,BG);M5.Display.setTextSize(sz);M5.Display.setCursor(x,y);M5.Display.print(s);
}
void centered(const String&s,int center,int y,int sz=2,uint32_t color=C_WHITE){
 M5.Display.setTextSize(sz);int width=M5.Display.textWidth(s);print(s,center-width/2,y,sz,color);
}
void rect(int x,int y,int w,int h,bool active=false){
 M5.Display.fillRoundRect(x,y,w,h,10,PANEL);M5.Display.drawRoundRect(x,y,w,h,10,active?C_ORANGE:EDGE);
}
void action(const String&s,int x,int y,int w,int h,bool active=false){
 rect(x,y,w,h,active);centered(s,x+w/2,y+(h-16)/2,2,active?C_YELLOW:C_WHITE);
}
void battery(bool force=false){
 int v=M5.Power.getBatteryLevel();if(v<0||v>100)v=-1;
 if(!force&&v==oldBattery)return;oldBattery=v;
 int x=W-170,y=28;
 M5.Display.fillRect(x-6,y-5,166,44,BG);
 M5.Display.drawRoundRect(x,y,42,24,4,C_ORANGE);
 M5.Display.fillRect(x+43,y+7,5,10,C_ORANGE);
 if(v>=0){int f=v*34/100;if(f>0)M5.Display.fillRect(x+4,y+4,f,16,v<=15?C_RED:C_YELLOW);}
 print(v<0?"--%":String(v)+"%",x+57,y+4,2,v<0?C_MUTED:C_WHITE);
}
void header(){
 M5.Display.fillScreen(BG);M5.Display.fillRect(0,0,W,4,C_ORANGE);
 print("TAB5 SYSTEM",26,25,3,C_ORANGE);battery(true);
 M5.Display.drawFastHLine(22,HEADER,W-44,EDGE);
}
void icon(int id,int x,int y){
 auto &d=M5.Display;uint32_t c=C_ORANGE;
 switch(id){
 case 0:d.drawLine(x+22,y+5,x+22,y+28,c);d.drawLine(x+22,y+5,x+36,y+1,c);d.drawLine(x+36,y+1,x+36,y+23,c);d.fillCircle(x+16,y+29,6,c);d.fillCircle(x+30,y+24,6,c);break;
 case 1:d.fillRoundRect(x+17,y+3,14,26,7,c);d.drawArc(x+24,y+23,17,17,0,180,c);d.drawLine(x+24,y+39,x+24,y+45,c);d.drawLine(x+14,y+45,x+34,y+45,c);break;
 case 2:for(int i=0;i<4;i++)for(int j=0;j<4;j++)d.fillRoundRect(x+2+i*12,y+2+j*12,9,9,2,(i+j)%3==0?C_YELLOW:EDGE);break;
 case 3:for(int i=0;i<9;i++){int h=(i%4==0?8:i%3==0?32:i%2==0?23:15);d.drawFastVLine(x+4+i*5,y+24-h/2,h,c);}break;
 case 4:d.drawRect(x+2,y+6,46,36,c);for(int i=1;i<7;i++)d.drawFastVLine(x+2+i*7,y+7,34,c);for(int i:{1,2,4,5})d.fillRect(x+2+i*7-3,y+7,5,18,c);break;
 case 5:d.drawRoundRect(x+8,y+3,32,43,3,c);for(int i=0;i<4;i++)d.drawFastHLine(x+15,y+13+i*8,18,c);break;
 case 6:d.drawLine(x+24,y+10,x+24,y+42,c);d.drawLine(x+4,y+8,x+4,y+39,c);d.drawLine(x+44,y+8,x+44,y+39,c);d.drawLine(x+4,y+8,x+24,y+12,c);d.drawLine(x+44,y+8,x+24,y+12,c);d.drawLine(x+4,y+39,x+24,y+43,c);d.drawLine(x+44,y+39,x+24,y+43,c);break;
 case 7:d.drawRect(x+9,y+5,31,39,c);d.fillRect(x+15,y+8,19,13,c);d.drawFastHLine(x+16,y+35,17,c);break;
 case 8:d.drawCircle(x+24,y+24,19,c);d.drawLine(x+8,y+25,x+16,y+25,c);d.drawLine(x+16,y+25,x+20,y+14,c);d.drawLine(x+20,y+14,x+27,y+35,c);d.drawLine(x+27,y+35,x+33,y+25,c);d.drawLine(x+33,y+25,x+41,y+25,c);break;
 default:d.drawRoundRect(x+8,y+8,32,32,6,EDGE);d.drawFastHLine(x+18,y+24,12,c);d.drawFastVLine(x+24,y+18,12,c);
 }
}
void home(){
 app=-1;editing=false;header();
 const int left=26,gap=14,top=HEADER+17,cw=(W-2*left-3*gap)/4,ch=(H-top-24-2*gap)/3;
 for(int i=0;i<COUNT;i++){
  int x=left+(i%4)*(cw+gap),y=top+(i/4)*(ch+gap);rect(x,y,cw,ch);
  // Icon and name form a vertically centered, horizontally centered group.
  int iy=y+(ch-110)/2;icon(i,x+cw/2-24,iy);
  centered(labels[i],x+cw/2,iy+63,2,i>=9?C_YELLOW:C_WHITE);
 }
}
void nav(const String&title){
 header();print(title,29,107,3,C_YELLOW);
 action("HOME",W-198,H-75,170,49,true);
}
bool mount(){
 if(sdOK)return true;
 SD_MMC.setPins(43,44,39,40,41,42);
 sdOK=SD_MMC.begin("/sdcard",false,false,20000);
 if(sdOK){for(const auto &d:dirs)if(!SD_MMC.exists(d))SD_MMC.mkdir(d);}
 return sdOK;
}
void scan(const String&path){
 count=0;scrollOffset=0;folder=path;if(!sdOK)return;
 File dir=SD_MMC.open(folder);if(!dir||!dir.isDirectory())return;
 File f=dir.openNextFile();
 while(f&&count<MAX_FILES){
  String n=String(f.name());int slash=n.lastIndexOf('/');if(slash>=0)n=n.substring(slash+1);
  if(n.length()){entries[count++]={n,folder=="/"?"/"+n:folder+"/"+n,f.isDirectory()};}
  f.close();f=dir.openNextFile();
 }
 dir.close();
}
bool isTxt(String p){p.toLowerCase();return p.endsWith(".txt")||p.endsWith(".md")||p.endsWith(".log");}
void listPage(){
 String title=app==7?"SD BROWSER":app==5?"NOTES":"EREADER";
 nav(title);
 print(sdOK?folder:"SD CARD NOT DETECTED",30,157,2,sdOK?C_MUTED:C_RED);
 if(!sdOK){print("Insert FAT32 microSD and tap RETRY",40,225,2);action("RETRY",40,300,190,55);return;}
 if(folder!="/")action("UP",30,203,125,49);
 if(app==5)action("NEW NOTE",175,203,220,49);
 action("PREV",W-340,203,135,49);action("NEXT",W-190,203,135,49);
 const int rowH=51,start=275,visible=7;
 for(int j=0;j<visible;j++){
  int i=scrollOffset+j;if(i>=count)break;
  int y=start+j*rowH;rect(32,y,W-64,rowH-5);
  String label=(entries[i].directory?"[DIR]  ":"[FILE]  ")+entries[i].name;
  if(label.length()>83)label=label.substring(0,80)+"...";
  print(label,48,y+12,2,entries[i].directory?C_YELLOW:C_WHITE);
 }
 print(String(count)+" entries"+(count>=MAX_FILES?" (limit 120)":""),30,H-61,1,C_MUTED);
}
void readFile(const String&p){
 filePath=p;readerOffset=0;editing=false;editor="";
 if(!sdOK)return;
 File f=SD_MMC.open(p,FILE_READ);
 if(!f){notice="Unable to open file";return;}
 // Bounded load: no unbounded allocations from malformed/huge files.
 const size_t maxBytes=65536;
 size_t len=f.size();if(len>maxBytes)len=maxBytes;
 editor.reserve(len+1);
 for(size_t i=0;i<len&&f.available();i++)editor+=(char)f.read();
 f.close();notice="";
}
void reader(){
 nav(app==5?"NOTE":"TEXT READER");
 String title=filePath;int cut=title.lastIndexOf('/');if(cut>=0)title=title.substring(cut+1);
 print(title.substring(0,65),30,158,2,C_MUTED);
 rect(28,199,W-56,H-300);
 M5.Display.setTextSize(2);
 const int maxChars=(W-90)/12, maxLines=(H-328)/29;
 int pos=readerOffset,line=0;String segment="";
 while(pos<(int)editor.length()&&line<maxLines){
  char c=editor[pos++];
  if(c=='\r')continue;
  if(c=='\n'||(int)segment.length()>=maxChars){
   print(segment,46,216+line*29,2);segment="";line++;
   if(c!='\n')segment+=c;
  }else segment+=c;
 }
 if(line<maxLines&&segment.length())print(segment,46,216+line*29,2);
 action("BACK",30,H-75,155,49);
 action("PREV",225,H-75,155,49);action("NEXT",400,H-75,155,49);
 if(app==5)action("EDIT",600,H-75,155,49);
 print(String(readerOffset)+"/"+String(editor.length())+" chars",790,H-58,1,C_MUTED);
}
void editorPage(){
 nav("NOTE EDITOR");
 print(filePath,30,160,2,C_MUTED);
 rect(28,195,W-56,145);
 String tail=editor.length()>180?editor.substring(editor.length()-180):editor;
 tail+="|"; // Solid insertion cursor; only redraws on input, no timer.
 int p=0;for(int l=0;l<4&&p<(int)tail.length();l++){
  String row=tail.substring(p,p+85);int e=row.indexOf('\n');if(e>=0)row=row.substring(0,e);
  print(row,45,212+l*29,2);p+=row.length()+((e>=0)?1:0);
 }
 const char* keys[]={"1234567890","QWERTYUIOP","ASDFGHJKL","ZXCVBNM"};
 for(int r=0;r<4;r++){
  String s=keys[r];int n=s.length(),keyW=(W-66)/10;
  for(int i=0;i<n;i++)action(s.substring(i,i+1),30+i*keyW,360+r*60,keyW-5,52);
 }
 action("SPACE",35,610,220,45);action("ENTER",265,610,170,45);
 action("DELETE",445,610,175,45);action("SAVE",630,610,160,45,true);
 action("CANCEL",800,610,165,45);
}
void saveNote(){
 if(!sdOK){notice="SD unavailable";return;}
 String temp=filePath+".tmp";
 SD_MMC.remove(temp);
 File f=SD_MMC.open(temp,FILE_WRITE);
 if(!f){notice="Save failed";return;}
 size_t n=f.print(editor);f.close();
 if(n!=editor.length()){notice="Write incomplete";return;}
 if(SD_MMC.exists(filePath))SD_MMC.remove(filePath);
 if(!SD_MMC.rename(temp,filePath)){notice="Rename failed; .tmp retained";return;}
 notice="Saved";dirty=false;
}
void diag(){
 nav("DIAGNOSTICS");
 rect(28,158,W-56,H-250);
 uint8_t mac[6]={};esp_read_mac(mac,ESP_MAC_BASE);
 char macStr[24];snprintf(macStr,sizeof(macStr),"%02X:%02X:%02X:%02X:%02X:%02X",mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]);
 String lines[]={
  "Firmware: Tab5 System v0.2a",
  "Chip: "+String(ESP.getChipModel())+"  /  "+String(ESP.getCpuFreqMHz())+" MHz",
  "Revision: "+String(ESP.getChipRevision())+"    Chip MAC: "+String(macStr),
  "Flash: "+String(ESP.getFlashChipSize()/1048576)+" MB",
  "Free internal RAM: "+String(heap_caps_get_free_size(MALLOC_CAP_INTERNAL)/1024)+" KB",
  "PSRAM: "+String(heap_caps_get_total_size(MALLOC_CAP_SPIRAM)/1048576)+" MB total",
  "Free PSRAM: "+String(heap_caps_get_free_size(MALLOC_CAP_SPIRAM)/1024)+" KB",
  "Display: "+String(W)+" x "+String(H),
  "SD: "+String(sdOK?"MOUNTED":"NOT MOUNTED")+(sdOK?"  /  "+String(SD_MMC.cardSize()/1048576)+" MB":""),
  "Uptime: "+String(millis()/1000)+" seconds"
 };
 for(int i=0;i<10;i++)print(lines[i],48,177+i*43,2,i==0?C_YELLOW:C_WHITE);
 action("REFRESH",35,H-75,185,49);
 if(!sdOK)action("RETRY SD",245,H-75,185,49);
}
void placeholder(){
 nav(labels[app]);rect(28,165,W-56,H-255);
 print(labels[app],55,212,3,C_ORANGE);
 print("Planned for the shared audio / sequencer milestone.",55,292,2,C_YELLOW);
 print("No audio engine is active in v0.2.",55,335,2,C_MUTED);
}
void draw(){
 if(app<0){home();return;}
 if(app==8){diag();return;}
 if(app==7||app==5||app==6){
  if(editing){editorPage();return;}
  if(filePath.length()){reader();return;}
  listPage();return;
 }
 placeholder();
}
void enter(int i){
 if(i>=9)return;
 app=i;filePath="";editing=false;notice="";
 if(i==5||i==6||i==7){if(!sdOK)mount();scan(i==5?"/Notes":i==6?"/Books":"/");}
 draw();
}
void parent(){
 if(folder=="/"){home();return;}
 int p=folder.lastIndexOf('/');scan(p<=0?"/":folder.substring(0,p));draw();
}
void openEntry(int idx){
 if(idx<0||idx>=count)return;
 if(entries[idx].directory){scan(entries[idx].path);draw();return;}
 if(app==7){notice="Browse only in v0.2";return;}
 if(!isTxt(entries[idx].path)){notice="TXT / MD / LOG only in v0.2";return;}
 readFile(entries[idx].path);draw();
}
void readerMove(bool forward){
 if(forward){readerOffset=min((int)editor.length(),readerOffset+1800);}
 else readerOffset=max(0,readerOffset-1800);
 draw();
}
void handle(int x,int y){
 if(app<0){
  const int left=26,gap=14,top=HEADER+17,cw=(W-2*left-3*gap)/4,ch=(H-top-24-2*gap)/3;
  for(int i=0;i<COUNT;i++){int px=left+(i%4)*(cw+gap),py=top+(i/4)*(ch+gap);
   if(x>=px&&x<px+cw&&y>=py&&y<py+ch){enter(i);return;}}
  return;
 }
 if(x>W-210&&y>H-88){if(editing){editing=false;draw();}else home();return;}
 if(app==8){if(y>H-90){if(x<235)diag();else if(x<460){mount();diag();}}return;}
 if(app!=5&&app!=6&&app!=7)return;
 if(editing){
  if(y>=360&&y<600){
   int row=(y-360)/60;int col=(x-30)/((W-66)/10);
   const char* keys[]={"1234567890","QWERTYUIOP","ASDFGHJKL","ZXCVBNM"};
   if(row>=0&&row<4&&col>=0&&col<(int)strlen(keys[row])&&x>=30){editor+=(char)keys[row][col];dirty=true;draw();}
  }else if(y>=605&&y<668){
   if(x<255)editor+=" ";
   else if(x<435)editor+="\n";
   else if(x<620){if(editor.length())editor.remove(editor.length()-1);}
   else if(x<800){saveNote();editing=false;}
   else{editing=false;readFile(filePath);}
   draw();
  }return;
 }
 if(filePath.length()){
  if(y>H-90){
   if(x<190){filePath="";scan(folder);draw();}
   else if(x<390)readerMove(false);
   else if(x<580)readerMove(true);
   else if(app==5&&x<780){editing=true;draw();}
  }return;
 }
 if(!sdOK){if(y>=290&&y<370){mount();scan(folder);draw();}return;}
 if(y>=200&&y<262){
  if(x<160&&folder!="/"){parent();return;}
  if(app==5&&x>=175&&x<400){
   filePath="/Notes/Note_"+String(millis()/1000)+".txt";
   editor="";editing=true;dirty=true;draw();return;
  }
  if(x>W-350&&x<W-200){scrollOffset=max(0,scrollOffset-7);draw();return;}
  if(x>W-195){scrollOffset=min(max(0,count-7),scrollOffset+7);draw();return;}
 }
 if(y>=275&&y<275+7*51){int idx=scrollOffset+(y-275)/51;openEntry(idx);}
}
}
void setup(){
 Serial.begin(115200);auto cfg=M5.config();M5.begin(cfg);
 M5.Display.setRotation(3);W=M5.Display.width();H=M5.Display.height();
 mount();home();batteryTick=millis();
 Serial.println("Tab5 System v0.2 started");
}
void loop(){
 M5.update();auto t=M5.Touch.getDetail();bool pressed=t.isPressed();
 if(pressed&&!touchDown)handle(t.x,t.y);touchDown=pressed;
 if((uint32_t)(millis()-batteryTick)>=60000){batteryTick=millis();battery();}
 delay(10);
}
