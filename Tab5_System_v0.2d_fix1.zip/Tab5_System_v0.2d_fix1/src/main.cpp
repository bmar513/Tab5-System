
#include <Arduino.h>
#include <M5Unified.h>
#include <M5GFX.h>
#include <SD_MMC.h>
#include <esp_heap_caps.h>
#include <esp_mac.h>
#include <cstring>
#include "Theme.h"

namespace {
constexpr uint32_t BG=Theme::BG, PANEL=Theme::PANEL, EDGE=Theme::EDGE;
constexpr uint32_t C_ORANGE=Theme::ORANGE,C_YELLOW=Theme::YELLOW,C_RED=Theme::RED;
constexpr uint32_t C_WHITE=Theme::WHITE,C_MUTED=Theme::MUTED;
constexpr int HEADER=65, COUNT=12, MAX_FILES=120;
const char* labels[COUNT]={"PLAYER","RECORDER","SEQUENCER","GENERATOR","SYNTH PIANO","NOTES","READER","SD","DIAGNOSTICS","LOREM","IPSUM","DOLOR"};
int W=1280,H=720,app=-1,scrollOffset=0,readerOffset=0,diagOffset=0,caret=0;
uint32_t readerNextOffset=0, readerFileSize=0;
String playerFolder="/Music", playerSelected="", seqSample[4]={"","","",""};
int playerIndex=0, seqBpm=120, seqStep=0, genWave=0, genFreq=440;
bool seqGrid[4][16]={}, seqRunning=false;
uint32_t seqTick=0;
const char* waveNames[]={"SINE","SQUARE","TRIANGLE","SAW","NOISE"};
bool shiftOn=true, symbolOn=false, confirmLeave=false;
int touchStartY=0;
bool sdOK=false, touchDown=false,editing=false,dirty=false;
uint32_t batteryTick=0;
int oldBattery=-999;
String folder="/", filePath="", editor="", notice="";
struct Entry {String name,path;bool directory;};
Entry entries[MAX_FILES];int count=0;
const char* const dirs[]={"/Music","/Recordings","/Samples","/Samples/Drums","/Samples/Synth","/Samples/Generated","/Patterns","/Notes","/Books","/Books/TXT","/Books/EPUB","/Books/PDF","/System","/System/Settings"};
void print(const String&s,int x,int y,int sz=2,uint32_t color=C_WHITE){
 M5.Display.setTextColor(color,BG);M5.Display.setTextSize(sz);M5.Display.setCursor(x,y);M5.Display.print(s);
}
void centered(const String&s,int center,int y,int sz=2,uint32_t color=C_WHITE){
 M5.Display.setTextSize(sz);int width=M5.Display.textWidth(s);print(s,center-width/2,y,sz,color);
}
void rect(int x,int y,int w,int h,bool active=false){
 M5.Display.fillRoundRect(x,y,w,h,10,PANEL);M5.Display.drawRoundRect(x,y,w,h,10,active?C_ORANGE:EDGE);
}
void action(const String&s,int x,int y,int w,int h,bool active=false){
 rect(x,y,w,h,active);centered(s,x+w/2,y+(h-16)/2,2,active?C_YELLOW:C_WHITE);
}
void battery(bool force=false){
 int v=M5.Power.getBatteryLevel();if(v<0||v>100)v=-1;
 if(!force&&v==oldBattery)return;oldBattery=v;
 int x=W-170,y=28;
 M5.Display.fillRect(x-6,y-5,166,44,BG);
 M5.Display.drawRoundRect(x,y,42,24,4,C_ORANGE);
 M5.Display.fillRect(x+43,y+7,5,10,C_ORANGE);
 if(v>=0){int f=v*34/100;if(f>0)M5.Display.fillRect(x+4,y+4,f,16,v<=15?C_RED:C_YELLOW);}
 print(v<0?"--%":String(v)+"%",x+57,y+4,2,v<0?C_MUTED:C_WHITE);
}
void header(const String&title="TAB5 SYSTEM"){
 M5.Display.fillScreen(BG);M5.Display.fillRect(0,0,W,4,C_ORANGE);
 String shown=title;M5.Display.setTextSize(3);
 while(shown.length()&&M5.Display.textWidth(shown)>W-235)shown.remove(shown.length()-1);
 if(shown!=title&&shown.length()>3){shown.remove(shown.length()-3);shown+="...";}
 print(shown,26,25,3,C_ORANGE);battery(true);
 M5.Display.drawFastHLine(22,HEADER,W-44,EDGE);
}
void icon(int id,int x,int y){
 auto &d=M5.Display;uint32_t c=C_ORANGE;
 switch(id){
 case 0:d.drawLine(x+22,y+5,x+22,y+28,c);d.drawLine(x+22,y+5,x+36,y+1,c);d.drawLine(x+36,y+1,x+36,y+23,c);d.fillCircle(x+16,y+29,6,c);d.fillCircle(x+30,y+24,6,c);break;
 case 1:d.fillRoundRect(x+17,y+3,14,26,7,c);d.drawArc(x+24,y+23,17,17,0,180,c);d.drawLine(x+24,y+39,x+24,y+45,c);d.drawLine(x+14,y+45,x+34,y+45,c);break;
 case 2:for(int i=0;i<4;i++)for(int j=0;j<4;j++)d.fillRoundRect(x+2+i*12,y+2+j*12,9,9,2,(i+j)%3==0?C_YELLOW:EDGE);break;
 case 3:for(int i=0;i<9;i++){int h=(i%4==0?8:i%3==0?32:i%2==0?23:15);d.drawFastVLine(x+4+i*5,y+24-h/2,h,c);}break;
 case 4:d.drawRect(x+2,y+6,46,36,c);for(int i=1;i<7;i++)d.drawFastVLine(x+2+i*7,y+7,34,c);for(int i:{1,2,4,5})d.fillRect(x+2+i*7-3,y+7,5,18,c);break;
 case 5:d.drawRoundRect(x+8,y+3,32,43,3,c);for(int i=0;i<4;i++)d.drawFastHLine(x+15,y+13+i*8,18,c);break;
 case 6:d.drawLine(x+24,y+10,x+24,y+42,c);d.drawLine(x+4,y+8,x+4,y+39,c);d.drawLine(x+44,y+8,x+44,y+39,c);d.drawLine(x+4,y+8,x+24,y+12,c);d.drawLine(x+44,y+8,x+24,y+12,c);d.drawLine(x+4,y+39,x+24,y+43,c);d.drawLine(x+44,y+39,x+24,y+43,c);break;
 case 7:d.drawRect(x+9,y+5,31,39,c);d.fillRect(x+15,y+8,19,13,c);d.drawFastHLine(x+16,y+35,17,c);break;
 case 8:d.drawCircle(x+24,y+24,19,c);d.drawLine(x+8,y+25,x+16,y+25,c);d.drawLine(x+16,y+25,x+20,y+14,c);d.drawLine(x+20,y+14,x+27,y+35,c);d.drawLine(x+27,y+35,x+33,y+25,c);d.drawLine(x+33,y+25,x+41,y+25,c);break;
 default:d.drawRoundRect(x+8,y+8,32,32,6,EDGE);d.drawFastHLine(x+18,y+24,12,c);d.drawFastVLine(x+24,y+18,12,c);
 }
}
void home(){
 app=-1;editing=false;header();
 const int left=26,gap=14,top=HEADER+17,cw=(W-2*left-3*gap)/4,ch=(H-top-24-2*gap)/3;
 for(int i=0;i<COUNT;i++){
  int x=left+(i%4)*(cw+gap),y=top+(i/4)*(ch+gap);rect(x,y,cw,ch);
  // Icon and name form a vertically centered, horizontally centered group.
  int iy=y+(ch-110)/2;icon(i,x+cw/2-24,iy);
  centered(labels[i],x+cw/2,iy+63,2,i>=9?C_YELLOW:C_WHITE);
 }
}
void nav(const String&title){
 header(title);action("HOME",W-198,H-75,170,49,true);
}
bool mount(){
 if(sdOK)return true;
 SD_MMC.setPins(43,44,39,40,41,42);
 sdOK=SD_MMC.begin("/sdcard",false,false,20000);
 if(sdOK){for(const auto &d:dirs)if(!SD_MMC.exists(d))SD_MMC.mkdir(d);}
 return sdOK;
}
void scan(const String&path){
 count=0;scrollOffset=0;folder=path;if(!sdOK)return;
 File dir=SD_MMC.open(folder);if(!dir||!dir.isDirectory())return;
 File f=dir.openNextFile();
 while(f&&count<MAX_FILES){
  String n=String(f.name());int slash=n.lastIndexOf('/');if(slash>=0)n=n.substring(slash+1);
  if(n.length()){entries[count++]={n,folder=="/"?"/"+n:folder+"/"+n,f.isDirectory()};}
  f.close();f=dir.openNextFile();
 }
 dir.close();
}
bool isTxt(String p){p.toLowerCase();return p.endsWith(".txt")||p.endsWith(".md")||p.endsWith(".log");}
void listPage(){
 String title=app==7?"SD":app==5?"NOTES":"READER";
 nav(title);
 print(sdOK?folder:"SD CARD NOT DETECTED",30,87,2,sdOK?C_MUTED:C_RED);
 if(!sdOK){print("Insert FAT32 microSD and tap RETRY",40,155,2);action("RETRY",40,220,190,55);return;}
 if(folder!="/")action("UP",30,127,125,49);
 if(app==5)action("NEW NOTE",175,127,220,49);
 action("PREV",W-340,127,135,49);action("NEXT",W-190,127,135,49);
 const int rowH=57,start=195,visible=8;
 for(int j=0;j<visible;j++){
  int i=scrollOffset+j;if(i>=count)break;
  int y=start+j*rowH;rect(32,y,W-64,rowH-5);
  String label=(entries[i].directory?"[DIR]  ":"[FILE]  ")+entries[i].name;
  if(label.length()>83)label=label.substring(0,80)+"...";
  print(label,48,y+15,2,entries[i].directory?C_YELLOW:C_WHITE);
 }
 print(String(count)+" entries"+(count>=MAX_FILES?" (limit 120)":""),30,H-61,1,C_MUTED);
 if(notice.length())print(notice,30,H-88,2,C_RED);
}
// Notes are editable in RAM (64 KiB maximum). Reader streams from SD.
String bookmarkPath(){
 String key=filePath;String result="/System/Settings/reader_";
 for(size_t i=0;i<key.length();i++){
  uint8_t c=(uint8_t)key[i];char hex[3];snprintf(hex,sizeof(hex),"%02X",c);
  result+=hex;
 }
 return result+".pos";
}
void saveBookmark(){
 if(app!=6||!sdOK||filePath.isEmpty())return;
 String path=bookmarkPath();SD_MMC.remove(path);
 File f=SD_MMC.open(path,FILE_WRITE);
 if(f){f.print((uint32_t)readerOffset);f.close();}
}
void loadBookmark(){
 if(app!=6||!sdOK||filePath.isEmpty())return;
 File f=SD_MMC.open(bookmarkPath(),FILE_READ);
 if(!f)return;
 String v=f.readStringUntil('\n');f.close();
 uint32_t off=(uint32_t)strtoul(v.c_str(),nullptr,10);
 if(off<readerFileSize)readerOffset=(int)off;
}
void readFile(const String&p){
 notice="";readerOffset=0;readerNextOffset=0;readerFileSize=0;
 editing=false;editor="";caret=0;dirty=false;confirmLeave=false;
 if(!sdOK){filePath="";notice="SD card not mounted";return;}
 File f=SD_MMC.open(p,FILE_READ);
 if(!f||f.isDirectory()){
  if(f)f.close();filePath="";notice="Unable to open text file";return;
 }
 size_t len=f.size();
 if(app==5){
  if(len>65536){f.close();filePath="";notice="Note exceeds 64 KiB editing limit";return;}
  if(!editor.reserve(len+1)){f.close();filePath="";notice="Not enough memory for note";return;}
  for(size_t i=0;i<len&&f.available();i++)editor+=(char)f.read();
  caret=editor.length();
 }else{
  readerFileSize=(uint32_t)len;
 }
 f.close();filePath=p;
 if(app==6)loadBookmark();
}
// Determine the exact next page boundary using the same wrapping as rendering.
// Does not allocate a book-sized String; a single page is read from SD.
uint32_t renderReaderPage(uint32_t offset,bool paint){
 File f=SD_MMC.open(filePath,FILE_READ);
 if(!f||f.isDirectory()){
  if(f)f.close();if(paint)print("Unable to read file from SD",46,103,2,C_RED);
  return offset;
 }
 uint32_t size=f.size();
 if(offset>size)offset=size;
 if(!f.seek(offset)){
  f.close();if(paint)print("Unable to seek in file",46,103,2,C_RED);
  return offset;
 }
 const int maxChars=(W-90)/12,maxLines=(H-210)/29;
 int line=0;String segment;segment.reserve(maxChars+2);
 uint32_t pos=offset;
 while(pos<size&&line<maxLines){
  int v=f.read();if(v<0)break;
  char c=(char)v;pos++;
  if(c=='\r')continue;
  if(c=='\n'||(int)segment.length()>=maxChars){
   if(paint)print(segment,46,103+line*29,2);
   segment="";line++;
   if(c!='\n'&&line<maxLines)segment+=c;
  }else segment+=c;
 }
 if(paint&&line<maxLines&&segment.length())print(segment,46,103+line*29,2);
 f.close();return pos;
}
void reader(){
 String title=filePath;int cut=title.lastIndexOf('/');if(cut>=0)title=title.substring(cut+1);
 nav((app==5?"NOTE : ":"READER : ")+title);
 rect(28,87,W-56,H-181);
 if(app==6){
  readerNextOffset=renderReaderPage((uint32_t)readerOffset,true);
  print(String(readerOffset)+" / "+String(readerFileSize)+" bytes",790,H-58,1,C_MUTED);
 }else{
  const int maxChars=(W-90)/12,maxLines=(H-210)/29;
  int pos=readerOffset,line=0;String segment="";
  while(pos<(int)editor.length()&&line<maxLines){
   char c=editor[pos++];if(c=='\r')continue;
   if(c=='\n'||(int)segment.length()>=maxChars){
    print(segment,46,103+line*29,2);segment="";line++;
    if(c!='\n')segment+=c;
   }else segment+=c;
  }
  if(line<maxLines&&segment.length())print(segment,46,103+line*29,2);
  print(String(readerOffset)+"/"+String(editor.length())+" chars",790,H-58,1,C_MUTED);
 }
 action("BACK",30,H-75,155,49);action("PREV",225,H-75,155,49);
 action("NEXT",400,H-75,155,49);
 if(app==5)action("EDIT",600,H-75,155,49);
}
struct Key {String label;int x,y,w,h;String value;};
Key keys[55];int keyCount=0;
void addKey(const String&label,int x,int y,int w,int h,const String&value){
 if(keyCount>=55)return;keys[keyCount++]={label,x,y,w,h,value};
}
void buildKeyboard(){
 keyCount=0;
 const int y0=333,step=57,keyW=91,keyGap=8;
 const char* rows[]={"QWERTYUIOP","ASDFGHJKL","ZXCVBNM"};
 for(int r=0;r<3;r++){
  String row=rows[r];int n=row.length();int left=(W-(n*(keyW+keyGap)-keyGap))/2;
  for(int i=0;i<n;i++){
   String c=row.substring(i,i+1);
   if(!shiftOn)c.toLowerCase();
   if(symbolOn){const char* symbols[]={"1234567890","@#$%&-+()","/:;!?.,"};
    String sr=symbols[r];if(i<(int)sr.length())c=sr.substring(i,i+1);else continue;
   }
   addKey(c,left+i*(keyW+keyGap),y0+r*step,keyW,49,c);
  }
 }
 addKey(shiftOn?"SHIFT ON":"SHIFT",28,447,124,49,"SHIFT");
 addKey("BACKSPACE",W-185,447,155,49,"BACKSPACE");
 addKey(symbolOn?"ABC":"?123",35,510,150,52,"MODE");
 addKey(",",195,510,90,52,",");
 addKey("SPACE",295,510,410,52," ");
 addKey(".",715,510,90,52,".");
 addKey("ENTER",815,510,175,52,"\n");
 addKey("<",1005,510,95,52,"LEFT");
 addKey(">",1110,510,95,52,"RIGHT");
 addKey("SAVE",35,584,200,54,"SAVE");
 addKey("CANCEL",250,584,200,54,"CANCEL");
}
void renderEditText(){
 // Show a text window near the cursor. The solid insertion bar is drawn as a
 // primitive; no blinking timer and no full-screen periodic redraw.
 const int charsPerLine=(W-95)/12, maxLines=7;
 int start=max(0,caret-charsPerLine*(maxLines-1));
 if(start>0){int nl=editor.lastIndexOf('\n',start);if(nl>=0&&start-nl<charsPerLine)start=nl+1;}
 int x=46,y=97,col=0,line=0;
 for(int i=start;i<=(int)editor.length()&&line<maxLines;i++){
  if(i==caret)M5.Display.fillRect(x,y,3,23,C_YELLOW);
  if(i==(int)editor.length())break;
  char c=editor[i];if(c=='\r')continue;
  if(c=='\n'||col>=charsPerLine){line++;col=0;x=46;y=97+line*30;if(line>=maxLines)break;if(c=='\n')continue;}
  print(String(c),x,y,2);x+=12;col++;
 }
}
void editorPage(){
 String name=filePath;int slash=name.lastIndexOf('/');if(slash>=0)name=name.substring(slash+1);
 nav("NOTE EDITOR : "+name);
 rect(28,83,W-56,235);renderEditText();
 buildKeyboard();for(int i=0;i<keyCount;i++)action(keys[i].label,keys[i].x,keys[i].y,keys[i].w,keys[i].h,keys[i].value=="SAVE");
 print(String("Cursor ")+String(caret)+" / "+String(editor.length()),W-285,601,1,C_MUTED);
 if(confirmLeave){rect(W/2-260,190,520,155,true);centered("DISCARD UNSAVED CHANGES?",W/2,207,2,C_YELLOW);
  action("DISCARD",W/2-230,262,210,55);action("KEEP EDITING",W/2+20,262,210,55);}
}
void saveNote(){
 if(!sdOK){notice="SD unavailable";return;}
 String temp=filePath+".tmp";
 SD_MMC.remove(temp);
 File f=SD_MMC.open(temp,FILE_WRITE);
 if(!f){notice="Save failed";return;}
 size_t n=f.print(editor);f.close();
 if(n!=editor.length()){notice="Write incomplete";return;}
 if(SD_MMC.exists(filePath))SD_MMC.remove(filePath);
 if(!SD_MMC.rename(temp,filePath)){notice="Rename failed; .tmp retained";return;}
 notice="Saved";dirty=false;
}
void diag(){
 nav("DIAGNOSTICS");rect(28,84,W-56,H-177);
 uint8_t mac[6]={};esp_read_mac(mac,ESP_MAC_BASE);
 char macStr[24];snprintf(macStr,sizeof(macStr),"%02X:%02X:%02X:%02X:%02X:%02X",mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]);
 String lines[]={
  "SOFTWARE: Tab5 System v0.2d",
  "Chip: "+String(ESP.getChipModel())+"  /  "+String(ESP.getCpuFreqMHz())+" MHz",
  "Revision: "+String(ESP.getChipRevision())+"    Chip MAC: "+String(macStr),
  "Flash: "+String(ESP.getFlashChipSize()/1048576)+" MB",
  "Free internal RAM: "+String(heap_caps_get_free_size(MALLOC_CAP_INTERNAL)/1024)+" KB",
  "PSRAM: "+String(heap_caps_get_total_size(MALLOC_CAP_SPIRAM)/1048576)+" MB total",
  "Free PSRAM: "+String(heap_caps_get_free_size(MALLOC_CAP_SPIRAM)/1024)+" KB",
  "Display: "+String(W)+" x "+String(H),
  "SD: "+String(sdOK?"MOUNTED":"NOT MOUNTED")+(sdOK?"  /  "+String(SD_MMC.cardSize()/1048576)+" MB":""),
  "Uptime: "+String(millis()/1000)+" seconds"
 };
 for(int i=diagOffset;i<10&&i<diagOffset+10;i++)print(lines[i],48,102+(i-diagOffset)*45,2,i==0?C_YELLOW:C_WHITE);
 action("REFRESH",35,H-75,185,49);
 if(!sdOK)action("RETRY SD",245,H-75,185,49);
}

void playerPage(){
 nav("PLAYER");
 print("FOLDER: "+playerFolder,35,87,2,C_YELLOW);
 action("UP",35,126,125,48);
 action("PREV",190,126,150,48);
 action("NEXT",360,126,150,48);
 action("REFRESH",530,126,170,48);
 print("Select a folder or WAV/MP3 track.",36,187,2,C_MUTED);
 const int start=228,rowH=49;
 for(int j=0;j<8;j++){
  int i=scrollOffset+j;if(i>=count)break;
  int y=start+j*rowH;
  rect(35,y,W-70,rowH-4,i==playerIndex);
  String n=String(entries[i].directory?"[DIR] ":"[TRACK] ")+entries[i].name;
  if(n.length()>80)n=n.substring(0,77)+"...";
  print(n,48,y+12,2,i==playerIndex?C_YELLOW:C_WHITE);
 }
 print("SELECTED: "+(playerSelected.isEmpty()?"NONE":playerSelected),35,H-69,1,C_MUTED);
 print("Audio playback engine not connected yet.",35,H-47,1,C_RED);
}
void seqSave(){
 if(!sdOK){notice="NO SD CARD";return;}
 File f=SD_MMC.open("/Patterns/Tab5_Draft.json",FILE_WRITE);
 if(!f){notice="SAVE FAILED";return;}
 f.print("{\"version\":1,\"bpm\":");f.print(seqBpm);f.print(",\"samples\":[");
 for(int r=0;r<4;r++){
  if(r)f.print(",");
  f.print("\"");
  // Paths chosen from known SD entries; escape JSON-special characters.
  for(size_t i=0;i<seqSample[r].length();i++){
   char c=seqSample[r][i];
   if(c=='"'||c=='\\')f.print("\\");
   if((unsigned char)c>=32)f.print(c);
  }
  f.print("\"");
 }
 f.print("],\"steps\":[");
 for(int r=0;r<4;r++){
  if(r)f.print(",");
  f.print("[");
  for(int j=0;j<16;j++){if(j)f.print(",");f.print(seqGrid[r][j]?"1":"0");}
  f.print("]");
 }
 f.print("]}");f.close();notice="Saved /Patterns/Tab5_Draft.json";
}
void seqLoad(){
 if(!sdOK){notice="NO SD CARD";return;}
 File f=SD_MMC.open("/Patterns/Tab5_Draft.json",FILE_READ);
 if(!f){notice="NO SAVED PATTERN";return;}
 String j=f.readString();f.close();
 int b=j.indexOf("\"bpm\":");if(b>=0)seqBpm=constrain(j.substring(b+6).toInt(),40,240);
 int p=j.indexOf("\"steps\":[");
 if(p<0){notice="INVALID PATTERN";return;}
 p=j.indexOf('[',p+8);
 if(p<0){notice="INVALID STEPS";return;}
 for(int r=0;r<4;r++){
  p=j.indexOf('[',p+1);
  if(p<0){notice="INCOMPLETE PATTERN";return;}
  int end=j.indexOf(']',p);
  if(end<0){notice="INCOMPLETE PATTERN";return;}
  int cursor=p+1;
  for(int c=0;c<16;c++){
   while(cursor<end&&(j[cursor]==' '||j[cursor]==','))cursor++;
   if(cursor>=end){notice="INVALID STEPS";return;}
   seqGrid[r][c]=(j[cursor]=='1');cursor++;
  }
  p=end;
 }
 notice="Pattern loaded";
}
void seqPage(){
 nav("SEQUENCER");
 print("16 STEP / 4 TRACK PATTERN",34,91,2,C_YELLOW);
 action("BPM -",36,137,145,51);
 action(String(seqBpm)+" BPM",195,137,170,51);
 action("BPM +",380,137,145,51);
 action(seqRunning?"STOP":"RUN",545,137,150,51);
 action("SAVE JSON",715,137,200,51);
 action("LOAD JSON",935,137,200,51);
 const int gx=173,gy=235,cell=59,gap=5;
 for(int r=0;r<4;r++){
  print("TRACK "+String(r+1),36,gy+r*88+16,2,C_ORANGE);
  for(int c=0;c<16;c++){
   int x=gx+c*(cell+gap),y=gy+r*88;
   M5.Display.fillRoundRect(x,y,cell,58,5,seqGrid[r][c]?C_ORANGE:PANEL);
   M5.Display.drawRoundRect(x,y,cell,58,5,c==seqStep?C_YELLOW:EDGE);
   centered(String(c+1),x+cell/2,y+20,1,seqGrid[r][c]?BG:C_WHITE);
  }
 }
 print("Pattern editing and JSON save/load; no sound engine yet.",36,615,2,C_MUTED);
 if(notice.length())print(notice,36,650,1,C_YELLOW);
}
void generatorPage(){
 nav("GENERATOR");
 print("WAVEFORM GENERATOR / UI PREVIEW",35,97,2,C_YELLOW);
 for(int i=0;i<5;i++)action(waveNames[i],36+i*239,168,218,64,i==genWave);
 print("FREQUENCY",45,297,2,C_ORANGE);
 action("-",370,279,100,65);
 action(String(genFreq)+" Hz",490,279,265,65,true);
 action("+",775,279,100,65);
 action("PREVIEW ONLY",45,415,350,68);
 print("WAV synthesis and export are not enabled yet.",45,515,2,C_MUTED);
}
void placeholder(){
 nav(labels[app]);rect(28,165,W-56,H-255);
 print(labels[app],55,212,3,C_ORANGE);
 print("Planned for the shared audio / sequencer milestone.",55,292,2,C_YELLOW);
 print("No audio engine is active in v0.2c.",55,335,2,C_MUTED);
}
void draw(){
 if(app<0){home();return;}
 if(app==8){diag();return;}
 if(app==0){playerPage();return;}
 if(app==2){seqPage();return;}
 if(app==3){generatorPage();return;}
 if(app==7||app==5||app==6){
  if(editing){editorPage();return;}
  if(filePath.length()){reader();return;}
  listPage();return;
 }
 placeholder();
}
void enter(int i){
 if(i>=9)return;
 app=i;diagOffset=0;filePath="";editing=false;notice="";
 if(i==0){if(!sdOK)mount();playerFolder="/Music";scan(playerFolder);playerIndex=0;}
 if(i==5||i==6||i==7){if(!sdOK)mount();scan(i==5?"/Notes":i==6?"/Books":"/");}
 draw();
}
void parent(){
 if(folder=="/"){home();return;}
 int p=folder.lastIndexOf('/');scan(p<=0?"/":folder.substring(0,p));draw();
}
void openEntry(int idx){
 if(idx<0||idx>=count)return;
 if(entries[idx].directory){scan(entries[idx].path);draw();return;}
 if(app==7){notice="SD browser is browse-only";draw();return;}
 if(!isTxt(entries[idx].path)){notice="TXT / MD / LOG only";draw();return;}
 readFile(entries[idx].path);draw();
}
void readerMove(bool forward){
 if(app==6){
  if(forward){
   if(readerNextOffset>(uint32_t)readerOffset)readerOffset=readerNextOffset;
  }else{
   // Recompute preceding page boundary without holding the book in RAM.
   uint32_t target=(uint32_t)readerOffset,at=0,previous=0;
   while(at<target){
    uint32_t next=renderReaderPage(at,false);
    if(next<=at||next>=target)break;
    previous=next;at=next;
   }
   readerOffset=previous;
  }
  saveBookmark();
 }else{
  if(forward)readerOffset=min((int)editor.length(),readerOffset+1800);
  else readerOffset=max(0,readerOffset-1800);
 }
 draw();
}
void handle(int x,int y){
 if(app<0){
  const int left=26,gap=14,top=HEADER+17,cw=(W-2*left-3*gap)/4,ch=(H-top-24-2*gap)/3;
  for(int i=0;i<COUNT;i++){int px=left+(i%4)*(cw+gap),py=top+(i/4)*(ch+gap);
   if(x>=px&&x<px+cw&&y>=py&&y<py+ch){enter(i);return;}}
  return;
 }
 if(editing&&confirmLeave){
  if(y>=262&&y<=320){
   if(x>=W/2-230&&x<W/2-20){confirmLeave=false;dirty=false;editing=false;filePath="";scan(folder);draw();}
   else if(x>=W/2+20&&x<W/2+230){confirmLeave=false;draw();}
  }return;
 }
 if(x>W-210&&y>H-88){
  if(app==6&&filePath.length())saveBookmark();
  if(editing&&dirty){confirmLeave=true;draw();}
  else home();return;
 }
 if(app==0){
  if(y>=126&&y<183){
   if(x<170){if(playerFolder!="/"){int p=playerFolder.lastIndexOf('/');playerFolder=p<=0?"/":playerFolder.substring(0,p);scan(playerFolder);}draw();return;}
   if(x>=190&&x<345){scrollOffset=max(0,scrollOffset-8);draw();return;}
   if(x>=360&&x<515){scrollOffset=min(max(0,count-8),scrollOffset+8);draw();return;}
   if(x>=530&&x<710){scan(playerFolder);draw();return;}
  }
  if(y>=228&&y<228+8*49){
   int idx=scrollOffset+(y-228)/49;
   if(idx<count){
    playerIndex=idx;
    if(entries[idx].directory){playerFolder=entries[idx].path;scan(playerFolder);}
    else playerSelected=entries[idx].path;
    draw();
   }
  }return;
 }
 if(app==2){
  if(y>=137&&y<194){
   if(x<185)seqBpm=max(40,seqBpm-5);
   else if(x>=380&&x<530)seqBpm=min(240,seqBpm+5);
   else if(x>=545&&x<705)seqRunning=!seqRunning;
   else if(x>=715&&x<925)seqSave();
   else if(x>=935&&x<1145)seqLoad();
   draw();return;
  }
  const int gx=173,gy=235,cell=59,gap=5;
  if(x>=gx&&x<gx+16*(cell+gap)&&y>=gy&&y<gy+4*88){
   int c=(x-gx)/(cell+gap),r=(y-gy)/88;
   if(c>=0&&c<16&&r>=0&&r<4&&(x-gx)%(cell+gap)<cell&&(y-gy)%88<58)
    seqGrid[r][c]=!seqGrid[r][c];
   draw();
  }return;
 }
 if(app==3){
  if(y>=168&&y<235){int i=(x-36)/239;if(x>=36&&i>=0&&i<5)genWave=i;}
  if(y>=279&&y<350){if(x>=370&&x<475)genFreq=max(20,genFreq-10);if(x>=775&&x<875)genFreq=min(20000,genFreq+10);}
  draw();return;
 }
 if(app==8){if(y>H-90){if(x<235)diag();else if(x<460){mount();diag();}}return;}
 if(app!=5&&app!=6&&app!=7)return;
 if(editing){
  for(int i=0;i<keyCount;i++){
   Key &k=keys[i];if(x<k.x||x>=k.x+k.w||y<k.y||y>=k.y+k.h)continue;
   if(k.value=="SHIFT")shiftOn=!shiftOn;
   else if(k.value=="MODE")symbolOn=!symbolOn;
   else if(k.value=="LEFT")caret=max(0,caret-1);
   else if(k.value=="RIGHT")caret=min((int)editor.length(),caret+1);
   else if(k.value=="BACKSPACE"){if(caret>0){editor.remove(caret-1,1);caret--;dirty=true;}}
   else if(k.value=="SAVE"){saveNote();if(!dirty){editing=false;readerOffset=0;}}
   else if(k.value=="CANCEL"){if(dirty)confirmLeave=true;else {editing=false;readFile(filePath);}}
   else {editor=editor.substring(0,caret)+k.value+editor.substring(caret);caret+=k.value.length();dirty=true;}
   draw();return;
  }
  // Touch in the editor text area positions the cursor approximately by character cell.
  if(y>=92&&y<305){
   int targetLine=(y-97)/30,targetCol=max(0,(x-46)/12);
   int start=max(0,caret-((W-95)/12)*6),line=0,col=0;
   int chosen=start;
   for(int i=start;i<=(int)editor.length();i++){
    if(line>targetLine||(line==targetLine&&col>=targetCol)){chosen=i;break;}
    chosen=i;
    if(i==(int)editor.length())break;
    if(editor[i]=='\n'||col>=(W-95)/12){line++;col=0;}else col++;
   }
   caret=chosen;draw();
  }
  return;
 }
 if(filePath.length()){
  if(y>H-90){
   if(x<190){if(app==6)saveBookmark();filePath="";scan(folder);draw();}
   else if(x<390)readerMove(false);
   else if(x<580)readerMove(true);
   else if(app==5&&x<780){caret=editor.length();editing=true;draw();}
  }return;
 }
 if(!sdOK){if(y>=210&&y<290){mount();scan(folder);draw();}return;}
 if(y>=127&&y<185){
  if(x<160&&folder!="/"){parent();return;}
  if(app==5&&x>=175&&x<400){
   filePath="/Notes/Note_"+String(millis()/1000)+".txt";
   editor="";caret=0;editing=true;dirty=true;draw();return;
  }
  if(x>W-350&&x<W-200){scrollOffset=max(0,scrollOffset-8);draw();return;}
  if(x>W-195){scrollOffset=min(max(0,count-8),scrollOffset+8);draw();return;}
 }
 if(y>=195&&y<195+8*57){int idx=scrollOffset+(y-195)/57;openEntry(idx);}
}
}
void setup(){
 Serial.begin(115200);auto cfg=M5.config();M5.begin(cfg);
 M5.Display.setRotation(3);W=M5.Display.width();H=M5.Display.height();
 mount();home();batteryTick=millis();
 Serial.println("Tab5 System v0.2d started");
}
void loop(){
 M5.update();auto t=M5.Touch.getDetail();bool pressed=t.isPressed();
 if(pressed&&!touchDown){touchStartY=t.y;}
 if(!pressed&&touchDown&&app==8){int delta=t.y-touchStartY;if(delta>35){diagOffset=max(0,diagOffset-2);diag();}else if(delta< -35){diagOffset=min(0,diagOffset+2);diag();}}
 if(pressed&&!touchDown)handle(t.x,t.y);touchDown=pressed;
 if((uint32_t)(millis()-batteryTick)>=60000){batteryTick=millis();battery();}
 if(app==2&&seqRunning&&(uint32_t)(millis()-seqTick)>=(uint32_t)(60000UL/(seqBpm*4UL))){
  seqTick=millis();seqStep=(seqStep+1)%16;seqPage();
 }
 delay(10);
}
