# Tab5 System v0.2d (source project)

Built on v0.2c. Open this inner project directory in VS Code/PlatformIO.

Changes:
- Reader bookmarks: save the byte offset of the current page on NEXT/PREV,
  BACK, and HOME, then resume at that offset next time the same TXT file opens.
  Bookmark files are stored under /System/Settings/reader_<hex encoded path>.pos.
  Files with exceptionally long names may exceed FAT filename limits.
- Player: browse SD folders starting at /Music; select a track. NO audio playback yet.
- Sequencer: four rows x 16 editable steps, BPM controls, moving playhead
  (visual only), save/load a single draft JSON pattern in /Patterns/Tab5_Draft.json.
  Sample paths are placeholders and sound playback is not implemented.
- Generator: nonfunctional waveform/frequency GUI preview.
- Diagnostics reports v0.2d.

Important:
- This source has not been compiled or tested on the physical Tab5.
- Existing Notes, Reader and SD browser behavior is retained.
- The visual sequencer RUN does not produce sound.
- Only one sequencer draft pattern is stored. Saving replaces the prior draft.
- No USB mass storage mode yet.

## fix1
Corrected C++ escape sequences at main.cpp lines 148 and 366 that prevented v0.2d from compiling. No feature changes.
