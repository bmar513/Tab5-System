Tab5 System v0.3d (source, experimental)

Based on confirmed compiling v0.3c Fix 1.
- Touch file-browser rows increased by 25%: Player 48 -> 60 px, SD/Notes/Reader 57 -> 71 px, Sequencer browser 52 -> 65 px.
- File-browser arrow buttons page by the number of visible entries.
- Player and SD/Notes/Reader arrow paging redraws only the list area, avoiding full-screen refresh.
- During each drawn list row, service MP3 decoder once to reduce audio starvation during folder redraw.
- MP3 buffering (32 KiB), volume persistence, transport controls retained.

Limitations: This is not a separate audio task. Long synchronous operations (SD scans, complete header redraws, other screens) may still interrupt audio. No local PlatformIO compile or on-device test was available. Keep v0.3c Fix 1 as fallback.

Open the directory containing platformio.ini in VS Code.


v0.3d Fix 1: Moved global notice declaration above serviceMp3DuringDraw() to resolve compile error at main.cpp:83.
