# Tab5 System v0.2b — UI, Notes and Reader refinements

Source-only PlatformIO project. Based on the working v0.2a firmware.

Changes:
- Home retains TAB5 SYSTEM; every app uses its own name in the top header.
- NOTES, NOTE EDITOR : filename, READER, READER : filename, SD, DIAGNOSTICS.
- Header filenames truncate to fit before the battery icon.
- eReader renamed Reader throughout the interface and source; /Books/ unchanged.
- Browser and reader content moved upward into the reclaimed vertical space.
- Notes: staggered QWERTY touch keyboard, Shift, symbols, Space, Enter,
  Backspace, left/right cursor movement, solid cursor and touch-to-position.
- Notes prompts before discarding unsaved edits on Home or Cancel.
- Diagnostics starts with SOFTWARE: Tab5 System v0.2b; manual refresh.
- No automatic whole-screen refresh for the cursor.

Existing limits remain: TXT/MD/LOG reader up to 64 KiB; SD listing 120 entries.
Player/Recorder/Sequencer/Generator/Synth remain placeholders. EPUB/PDF and USB
mass storage are NOT implemented in this revision.

Test on hardware before relying on note saving or editing. Not compiled on this host.

Build/upload from project directory:
& "$env:USERPROFILE\.platformio\penv\Scripts\platformio.exe" run -e tab5 -t upload --upload-port COM7
