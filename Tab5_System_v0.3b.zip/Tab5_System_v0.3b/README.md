# Tab5 System v0.3b — MP3 and Generator preview experiment

Open the project folder containing `platformio.ini` in VS Code and use PlatformIO Build and Upload.

Changes from v0.3a:
- Header speaker icon scaled down and aligned with battery. TAB5 SYSTEM header text moved up 3 px.
- MP3 decoding with ESP8266Audio and the M5Unified speaker output. MP3 files stream from SD_MMC through AudioFileSourceFS, rather than loading into PSRAM.
- Player still supports its existing PCM WAV implementation.
- Generator adds HOLD TO TEST: press and hold to hear the selected waveform at the selected frequency, release to stop. EXPORT 3s WAV remains.
- Global volume popup retained.
- Diagnostics version changed to v0.3b.

IMPORTANT:
- This firmware has NOT been compiled or tested on Tab5 hardware.
- The first build downloads the new ESP8266Audio dependency via PlatformIO; internet is required.
- MP3 decoding is cooperative in the main loop. Long screen redraws may cause brief glitches.
- The Player's existing Pause is not a real resume; MP3 play after pause restarts the track.
- Seeking +/- 15 seconds is not implemented.
- The Sequencer remains visual-only; recorder microphone capture remains unimplemented.
- The existing four-pattern slots have not yet been redesigned.
- The shutdown click is likely an amplifier power transition. The firmware does not intentionally play sound at Home; no unverified hardware shutdown changes were added.
