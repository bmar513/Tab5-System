# Tab5 System v0.3a — experimental source release

Open the folder containing `platformio.ini` in VS Code and use PlatformIO Build/Upload.

Changes from v0.3:
- Global speaker button immediately left of battery. Popup volume +/- in 5% increments, 0% mute, speaker tap toggles mute and restores previous level. Applies M5Unified speaker volume.
- Expanded SD and Reader directory listings upward to use the empty row formerly occupied by buttons, including corresponding touch regions. Notes list retains NEW NOTE row.
- Explicit M5.Speaker.begin() at boot so the existing WAV Player can attempt real audio output; volume starts at 50%.
- All previous v0.3 features remain, including WAV Player, waveform WAV export, Reader, Notes, and Sequencer.

**Limitations:** This release has not been compiled or hardware tested. MP3 decoding, sequencer sample audio, recorder microphone capture, and named pattern browser replacing the four slots are NOT implemented. The existing WAV Player requires a supported WAV file no larger than 8 MB. A hardware speaker/codec configuration may still be required for sound. Test with a small PCM WAV before concluding audio works.
