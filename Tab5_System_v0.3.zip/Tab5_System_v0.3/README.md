# Tab5 System v0.3 — experimental media milestone

Open **Tab5_System_v0.3** (the directory containing `platformio.ini`) in VS Code.

## Implemented in source
- File-browser navigation moved to slim right-hand vertical up/down buttons on Player,
  Reader, Notes, SD, and Sequencer pickers. UP/REFRESH actions at lower left.
- Player transport row, file browsing, and **experimental WAV playback** through
  `M5.Speaker.playWav` after loading a complete WAV into PSRAM (max 8 MiB).
- Sequencer: tap TRACK 1–4 to assign an SD sample path, 16-step editing, BPM,
  visual playhead, JSON save/load with tempo and sample paths, four named save slots.
- Generator: waveform preview and 3-second mono 16-bit PCM WAV export to
  `/Samples/Generated/`.
- Reader bookmarks and Notes editor carried forward from v0.2d_fix1.

## NOT YET FUNCTIONAL — please read before testing
- **Recorder** is a layout/meter placeholder. RECORD explicitly reports that the
  microphone is not connected; it does not create recordings.
- Sequencer's RUN is a visual playhead only; assigned samples are not played.
- Player's -15s/+15s buttons are placeholders (streamed seeking not implemented).
- Player PAUSE currently stops and restarting begins the WAV again.
- MP3 playback is not implemented. WAV compatibility depends on M5Unified's decoder
  and the Tab5 audio output setup.
- The new source has **not been compiled or tested on a physical Tab5**.

## Safety
- Back up important SD content before testing experimental JSON save/load and
  Generator WAV writing.
- The Save As dialog currently has four named slots (`Pattern_1.json` through
  `Pattern_4.json`), not arbitrary filenames. The Load browser can see other JSONs.
- No PC USB mass-storage mode is implemented.
