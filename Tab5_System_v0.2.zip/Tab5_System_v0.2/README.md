# Tab5 System v0.2 — SD and text milestone

Based on the user's working v0.1 Tab5 firmware. Source-only project, no .pio folder.

## Features
- 12-button home, orange/yellow/red on black, centered icons/labels, no descriptions.
- Home has no subtitle. Diagnostics displays version, chip MAC (NOT factory serial), RAM, flash, SD and uptime; refresh on demand.
- Battery updates every 60 seconds only when its reading changes.
- Tab5 SD_MMC pins CLK=43 CMD=44 D0=39 D1=40 D2=41 D3=42.
- SD browser supports directory navigation (read-only, up to 120 entries per folder).
- Notes: basic on-screen uppercase keyboard; create, open and save TXT files (up to 64 KiB loaded).
- eReader: basic TXT/MD/LOG text paging (up to 64 KiB loaded). EPUB and PDF NOT implemented yet.
- Player, Recorder, Sequencer, Generator, Synth Piano remain explicit placeholders.
- LOREM, IPSUM, DOLOR are inert.

## SD card
Use FAT32 microSD. Firmware attempts to create:
 /Music /Recordings /Samples /Samples/Drums /Samples/Synth /Samples/Generated
 /Patterns /Notes /Books /Books/TXT /Books/EPUB /Books/PDF /System /System/Settings

Add your own text files to /Books and /Notes. No files are required for startup.
If the SD card is absent, the UI still boots and Diagnostics shows NOT MOUNTED.

## Limitations
The v0.2 Notes editor is deliberately simple: uppercase characters, numbers, space, newline,
backspace, save. This is not a full keyboard driver. Files over 64 KiB are truncated in memory
and should not be edited/saved. Directory listing is capped at 120 entries per folder.
No native PDF, EPUB, MP3, WAV or sequencer yet.
No automatic SD hotplug detection: use RETRY in the file browser or Diagnostics.
This release is not hardware-tested or locally compiled; verify on the Tab5 before relying on notes.

## Build
From this project folder:
 & "$env:USERPROFILE\.platformio\penv\Scripts\platformio.exe" run -e tab5 -t upload --upload-port COM7
