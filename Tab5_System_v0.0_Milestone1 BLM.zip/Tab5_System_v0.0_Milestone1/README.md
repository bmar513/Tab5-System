# Tab5 System v0.0 — Milestone 1

This is a **first hardware-test source project**, not a finished nine-app firmware.

## Included
- Landscape home screen with 9 touch-selectable apps in 4 columns.
- Dark/cyan styling, app title screens, consistent touch-to-home navigation.
- Live Diagnostics: chip, clock, flash, free internal RAM, PSRAM, screen, uptime.
- App placeholders for Player, Recorder, Sequencer, Generator, Synth Piano, Notes, eReader, and SD.

## Not yet implemented
- Keyboard, battery reporting, SD mounting/file management, audio recording/playback, LVGL, external image assets, eReader, and application engines.
- **Do not assume the physical keyboard works in this build.**

## Build (Windows / VS Code PlatformIO)
1. Open this folder in VS Code / PlatformIO.
2. Run `pio run -e tab5` in the project terminal.
3. Do not flash until compilation succeeds. Confirm the Tab5 serial port and make a backup of the factory firmware first if you want a restoration path.
4. Upload with `pio run -e tab5 -t upload --upload-port COMx` (replace COMx with your verified port).

Uses M5Stack's published PlatformIO configuration for Tab5 (pioarduino platform 54.03.21). It requires downloading dependencies on first build. This source has **not** been compiled or tested on physical Tab5 hardware in this environment.

## Compatibility warning
Tab5 display controllers vary by manufacturing revision (ILI9881C, ST7123, ST7121). Use current M5Unified >= 0.2.23 and M5GFX >= 0.2.30, as M5Stack recommends. If display or touch does not initialize, check the library versions and hardware revision before changing pin assignments.

## Roadmap
Milestone 2: keyboard, SD, battery, touch validation; asset loader / theme support.
Milestone 3: shared audio library and Player/Recorder.
Milestone 4: 16-step Sequencer, Wave Generator, Synth Piano.
Milestone 5: Notes, eReader, file manager, polish.
