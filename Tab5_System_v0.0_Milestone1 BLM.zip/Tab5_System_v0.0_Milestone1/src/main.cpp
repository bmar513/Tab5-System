#include <Arduino.h>
#include <M5Unified.h>
#include <M5GFX.h>
#include <esp_heap_caps.h>

// Tab5 System v0.0 milestone 1: display/touch navigation + live diagnostics.
// This build deliberately does not initialize or modify SD, audio, or keyboard hardware.
namespace {
constexpr uint32_t BG = 0x071018;
constexpr uint32_t PANEL = 0x12212C;
constexpr uint32_t PANEL_EDGE = 0x35505D;
constexpr uint32_t ACCENT = 0x00D7D2;
constexpr uint32_t WHITE = 0xF4FAFF;
constexpr uint32_t MUTED = 0x9DB3BE;
constexpr int HEADER_H = 94;
constexpr int FOOTER_H = 44;
const char* const labels[] = {"PLAYER", "RECORDER", "SEQUENCER", "GENERATOR", "SYNTH PIANO", "NOTES", "EREADER", "SD", "DIAGNOSTICS"};
const char* const descriptions[] = {
  "Music and saved clips", "Record and trim WAV samples", "16-step sample patterns",
  "Create waveform samples", "Keyboard and clip recording", "Text editor",
  "Books and reading position", "SD file management", "Hardware and memory"
};
constexpr int APP_COUNT = sizeof(labels) / sizeof(labels[0]);
int activeApp = -1;
int screenW = 1280;
int screenH = 720;
uint32_t lastDiag = 0;
bool touchWasDown = false;

void text(const String& s, int x, int y, int scale, uint32_t color) {
  M5.Display.setTextColor(color, BG);
  M5.Display.setTextSize(scale);
  M5.Display.setCursor(x, y);
  M5.Display.print(s);
}
void panel(int x, int y, int w, int h, bool selected = false) {
  M5.Display.fillRoundRect(x, y, w, h, 14, PANEL);
  M5.Display.drawRoundRect(x, y, w, h, 14, selected ? ACCENT : PANEL_EDGE);
}
void chrome(const String& page) {
  M5.Display.fillScreen(BG);
  M5.Display.fillRect(0, 0, screenW, 5, ACCENT);
  text("TAB5 SYSTEM", 26, 24, 3, WHITE);
  text("TAB5  /  v0.0", 28, 63, 1, MUTED);
  M5.Display.setTextSize(2);
  M5.Display.setTextColor(ACCENT, BG);
  M5.Display.setCursor(screenW - 22 - page.length() * 12, 43);
  M5.Display.print(page);
  M5.Display.drawFastHLine(22, HEADER_H, screenW - 44, PANEL_EDGE);
  M5.Display.drawFastHLine(22, screenH - FOOTER_H, screenW - 44, PANEL_EDGE);
  text("MILESTONE 1  /  TOUCH UI", 26, screenH - 30, 1, MUTED);
}
void drawHome() {
  chrome("HOME");
  const int gap = 14, left = 26, top = HEADER_H + 18;
  const int cardW = (screenW - left * 2 - gap * 3) / 4;
  const int cardH = (screenH - FOOTER_H - top - 24 - gap * 2) / 3;
  for (int i = 0; i < APP_COUNT; ++i) {
    const int col = i % 4, row = i / 4;
    const int x = left + col * (cardW + gap), y = top + row * (cardH + gap);
    panel(x, y, cardW, cardH);
    M5.Display.fillCircle(x + 33, y + 34, 13, ACCENT);
    text(String(i + 1), x + 26, y + 25, 2, BG);
    text(labels[i], x + 20, y + 65, 2, WHITE);
    text(descriptions[i], x + 20, y + 102, 1, MUTED);
  }
}
void drawDiagnostics() {
  chrome("DIAGNOSTICS");
  panel(26, 112, screenW - 52, screenH - 112 - FOOTER_H - 16);
  const size_t freeInternal = heap_caps_get_free_size(MALLOC_CAP_INTERNAL);
  const size_t freePsram = heap_caps_get_free_size(MALLOC_CAP_SPIRAM);
  const size_t totalPsram = heap_caps_get_total_size(MALLOC_CAP_SPIRAM);
  const String rows[] = {
    "CPU: " + String(ESP.getChipModel()) + "  |  " + String(ESP.getCpuFreqMHz()) + " MHz",
    "Chip revision: " + String(ESP.getChipRevision()),
    "Flash: " + String(ESP.getFlashChipSize() / 1024 / 1024) + " MB",
    "Internal free heap: " + String(freeInternal / 1024) + " KB",
    "PSRAM: " + String(totalPsram / 1024 / 1024) + " MB total / " + String(freePsram / 1024 / 1024) + " MB free",
    "Display: " + String(screenW) + " x " + String(screenH),
    "Uptime: " + String(millis() / 1000) + " sec",
    "SD, keyboard, audio: pending hardware validation"
  };
  for (int i = 0; i < 8; ++i) {
    text(rows[i], 55, 140 + i * 53, 2, i == 7 ? MUTED : WHITE);
  }
  panel(screenW - 206, screenH - 91, 178, 43, true);
  text("< HOME", screenW - 184, screenH - 79, 2, ACCENT);
}
void drawApp() {
  if (activeApp < 0) { drawHome(); return; }
  if (activeApp == 8) { drawDiagnostics(); return; }
  chrome(labels[activeApp]);
  panel(26, 115, screenW - 52, screenH - 115 - FOOTER_H - 16);
  text(labels[activeApp], 58, 165, 3, WHITE);
  text(descriptions[activeApp], 58, 226, 2, MUTED);
  text("UI placeholder - application engine comes in later milestones", 58, 300, 2, ACCENT);
  panel(screenW - 206, screenH - 91, 178, 43, true);
  text("< HOME", screenW - 184, screenH - 79, 2, ACCENT);
}
void handleTouch(int x, int y) {
  if (activeApp >= 0) {
    if (y < HEADER_H || (x > screenW - 235 && y > screenH - 113)) {
      activeApp = -1; drawHome();
    }
    return;
  }
  const int gap = 14, left = 26, top = HEADER_H + 18;
  const int cardW = (screenW - left * 2 - gap * 3) / 4;
  const int cardH = (screenH - FOOTER_H - top - 24 - gap * 2) / 3;
  for (int i = 0; i < APP_COUNT; ++i) {
    int px = left + (i % 4) * (cardW + gap);
    int py = top + (i / 4) * (cardH + gap);
    if (x >= px && x < px + cardW && y >= py && y < py + cardH) {
      activeApp = i; drawApp(); return;
    }
  }
}
}

void setup() {
  Serial.begin(115200);
  auto cfg = M5.config();
  M5.begin(cfg);
  M5.Display.setRotation(1);
  screenW = M5.Display.width();
  screenH = M5.Display.height();
  drawHome();
  Serial.println("Tab5 System v0.0 milestone 1 ready");
}

void loop() {
  M5.update();
  auto t = M5.Touch.getDetail();
  bool down = t.isPressed();
  if (down && !touchWasDown) handleTouch(t.x, t.y);
  touchWasDown = down;
  if (activeApp == 8 && millis() - lastDiag > 1500) {
    lastDiag = millis(); drawDiagnostics();
  }
  delay(10);
}
